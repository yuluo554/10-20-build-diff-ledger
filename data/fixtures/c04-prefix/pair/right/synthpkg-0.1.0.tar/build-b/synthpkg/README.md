# synthpkg

合成样张；由 `tools/gen_fixtures` 程序化生成，不含真实内容。
