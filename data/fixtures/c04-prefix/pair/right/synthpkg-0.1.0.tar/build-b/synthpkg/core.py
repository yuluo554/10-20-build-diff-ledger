"""synthpkg core — 合成样张，不含任何真实实现。"""

VERSION = "0.1.0"

def digest(payload):
    return payload
